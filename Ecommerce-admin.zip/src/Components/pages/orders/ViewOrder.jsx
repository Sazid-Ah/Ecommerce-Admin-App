import React from "react";

const ViewOrder = () => {
  const order = {
    orderId: 100013,
    paymentStatus: "unpaid",
    vendorName: "Vendor XYZ",
    orderDate: "2023-07-07 12:22",
  };

  const stylebest = {
    marginRight: "10",
    // padding-right:40px; // Adjust this value to control the space between the columns
  };
  return (
    <div>
      <div className="container">
        <div className="row">
          <div className="col-lg-12">
            <p>Orders / Order Details</p>
          </div>
          <div className="col-lg-2">
            <h5>Order #100013</h5>
          </div>
          <div className="col-lg-1">
            <p class="data1" style={stylebest}>
              unpaid
            </p>
          </div>
          <div className="col-lg-1">
            <p class="data1" style={stylebest}>
              pending
            </p>
          </div>
          <div className="col-lg-2">
            <i class="fa fa-calendar" aria-hidden="true">
              {" "}
              07 Jul 2023 12:22
            </i>
          </div>
          <div className="col-lg-6"></div>

          <div className="col-lg-4">
            <p>
              <i class="fa fa-print" aria-hidden="true">
                {" "}
                Print Invoice{" "}
              </i>
            </p>
          </div>
          <div className="col-lg-4">
            <p>
              <i class="fa fa-home" aria-hidden="true">
                {" "}
                Vendor : Ayushi mart
              </i>
            </p>
          </div>
          <div className="col-lg-4">
            <p>Show locations on map</p>
          </div>

          <div className="row">
            <div className="col-lg-8">
              <div className="row">
                <div className="col-lg-6">
                  <h4>Order Details </h4>
                </div>

                <div className="col-lg-6">
                  <button type="button" class="btn btn-info">
                    <i class="fa fa-pencil" aria-hidden="true"></i>Edit
                  </button>
                </div>
              </div>
              <hr />

              <div className="row">
                <div className="col-lg-4">
                  <p>Order Note :</p>
                </div>

                <div className="col-lg-8">
                  <p>Payment Method : Cash On Delivery</p>
                  <p>
                    Reference Code :{" "}
                    <a href="">
                      <button type="button" class="btn btn-info">
                        Add
                      </button>
                    </a>
                  </p>

                  <p>Order Type : Delivery</p>
                </div>

                <hr />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewOrder;
